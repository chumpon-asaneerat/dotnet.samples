﻿Imports System.ComponentModel

Public Class MainWindowViewModel
    Inherits ViewModelBase

    Private _filter As String
    Public Property Filter() As String
        Get
            If String.IsNullOrEmpty(_filter) Then _filter = String.Empty
            Return _filter
        End Get
        Set(ByVal value As String)
            _filter = value
            OnPropertyChanged()
            If moviesView IsNot Nothing Then moviesView.Refresh()
        End Set
    End Property

    Private _movies As List(Of String)
    Public Property Movies() As List(Of String)
        Get
            If _movies Is Nothing Then _movies = New List(Of String)
            Return _movies
        End Get
        Set(ByVal value As List(Of String))
            _movies = value
            OnPropertyChanged()
        End Set
    End Property

    Private moviesView As ICollectionView

    Public Sub New()
        Movies.Add("Black Panther")
        Movies.Add("Iron Man")
        Movies.Add("The Winner")
        Movies.Add("Winning")
        Movies.Add("Win Win")
        Movies.Add("Batman Begins")
        Movies.Add("Wonder Woman")
        Movies.Add("Gone with the Wind")
        Movies.Add("Winnie the Pooh")
        Movies.Add("Fast & Furious")
        Movies.Add("The Martian")

        moviesView = CollectionViewSource.GetDefaultView(Movies)
        moviesView.Filter = Function(w) CType(w, String).Contains(Filter, StringComparison.CurrentCultureIgnoreCase)
    End Sub
End Class
